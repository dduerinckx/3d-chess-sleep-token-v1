export type Node = {
  move?: string
  suffix?: string
  nag?: string
  comment?: string
  variations: Node[]
}
