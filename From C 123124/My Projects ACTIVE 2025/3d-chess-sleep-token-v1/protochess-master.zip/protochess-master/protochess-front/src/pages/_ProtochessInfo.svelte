<h1 class="title">Protochess</h1>
<h2 class="subtitle">Chess with custom pieces and boards</h2>

<figure style="float:right; width: 10em; margin: 1em" class="image">
    <img class="is-rounded" src="images/zebra.png">
</figure>
<div class="is-size-6">
    Are you a chess grandmaster? Or maybe you barely know the rules of chess? Either way, Protochess allows you to customize chess to your heart's content.
    Create your own boards/pieces using the built-in editor and then play against your friends (or the computer if you don't have friends).
    Here are some ideas to get you started:
    <ul style="color:dodgerblue">
        <li>A piece that attacks and moves like a knight + queen.</li>
        <li>A piece that moves north and south but attacks like a knight.</li>
        <li>A 6x5 board with only pawns and kings.</li>
        <li>A piece that can only move but not attack.</li>
        <li>A piece that does nothing but die.</li>
        <li>....Or anything you want!</li>
    </ul>
</div>
