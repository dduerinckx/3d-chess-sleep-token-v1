export const DisplayMode = {
    ALL: 0,
    TRANSLATE: 1,
    ATTACK: 2
}
