<script>
  import { Router } from "@sveltech/routify";
  import { routes } from "@sveltech/routify/tmp/routes";
  import 'bulma/css/bulma.css';
</script>

<Router {routes} />