# protochess-front

Frontend website for protochess.com. Uses [Routify](https://github.com/sveltech/routify) for SPA routing (with SSR/pre-rendering disabled).

### Get started

To run a dev server 
```
npm install
npm run dev
```

## Building

```
npm run build
```
This builds the SPA into /dist
