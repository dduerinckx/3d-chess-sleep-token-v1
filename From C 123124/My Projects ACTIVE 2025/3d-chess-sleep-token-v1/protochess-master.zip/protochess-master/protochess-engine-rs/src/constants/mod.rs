pub mod fen;
pub const DEFAULT_WIDTH:u8 = 8;
pub const DEFAULT_HEIGHT:u8 = 8;
