Shared data structures between Javascript/Websocket server, serialized with Serde
