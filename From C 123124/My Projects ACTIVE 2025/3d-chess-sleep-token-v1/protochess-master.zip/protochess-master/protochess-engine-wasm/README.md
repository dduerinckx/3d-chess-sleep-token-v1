## Rust -> WASM Bindings for Protochess
This crate uses wasm-bindgen to compile the protochess-engine to web assembly.
