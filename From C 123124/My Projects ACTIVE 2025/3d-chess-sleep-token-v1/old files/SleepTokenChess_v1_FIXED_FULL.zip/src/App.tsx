import React from 'react';
import Chess3D from './components/Chess3D';

export default function App() {
  return <Chess3D />;
}
