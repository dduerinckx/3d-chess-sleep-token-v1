
// ===============================================================
// 3D Chess Game Scaffold with Model Fallback Handling
// File: src/components/Chess3D.tsx
// ===============================================================

import React, { useState, useCallback, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, useGLTF } from '@react-three/drei';
import * as THREE from 'three';

type Color = 'white' | 'black';
interface Position { x: number; y: number; }
interface Piece { id: string; type: 'pawn' | 'rook' | 'knight' | 'bishop' | 'queen' | 'king'; color: Color; position: Position; }
type BoardState = Piece[];
interface Move { piece: Piece; to: Position; }
type MoveHistory = Move[];

function getPieceAtPosition(board: BoardState, pos: Position): Piece | null {
  return board.find(p => p.position.x === pos.x && p.position.y === pos.y) || null;
}
function isValidMove(piece: Piece, target: Position, board: BoardState, history: MoveHistory): boolean {
  return target.x >= 0 && target.x < 8 && target.y >= 0 && target.y < 8;
}
function makeMove(piece: Piece, target: Position, board: BoardState): BoardState {
  const filtered = board.filter(p => !(p.position.x === target.x && p.position.y === target.y));
  const updated = { ...piece, position: target };
  return filtered.map(p => (p.id === piece.id ? updated : p));
}

const pieceModelURLs: Record<Color, Record<Piece['type'], string>> = {
  white: {
    king: '', queen: '', bishop: '', knight: '', rook: '', pawn: '',
  },
  black: {
    king: '', queen: '', bishop: '', knight: '', rook: '', pawn: '',
  },
};

const PlaceholderPiece: React.FC<{ piece: Piece; onClick: (pos: Position) => void; isSelected: boolean; isValidMove: boolean }> = ({ piece, onClick, isSelected, isValidMove }) => {
  let geom: THREE.BufferGeometry;
  switch (piece.type) {
    case 'pawn': geom = new THREE.CylinderGeometry(0.2, 0.2, 0.6, 16); break;
    case 'rook': geom = new THREE.BoxGeometry(0.4, 0.6, 0.4); break;
    case 'knight': geom = new THREE.ConeGeometry(0.2, 0.6, 16); break;
    case 'bishop': geom = new THREE.ConeGeometry(0.15, 0.8, 16); break;
    case 'queen': geom = new THREE.CylinderGeometry(0.25, 0.25, 0.8, 16); break;
    case 'king': geom = new THREE.TorusGeometry(0.3, 0.1, 16, 100); break;
    default: geom = new THREE.SphereGeometry(0.3, 16, 16);
  }
  const mat = new THREE.MeshStandardMaterial({ color: piece.color === 'white' ? '#fff' : '#000' });
  return (
    <mesh geometry={geom} material={mat} position={[piece.position.x - 3.5, 0.3, piece.position.y - 3.5]} onClick={() => onClick(piece.position)} castShadow>
      {isSelected && <mesh><ringGeometry args={[0.6, 0.7, 32]} /><meshBasicMaterial color="blue" side={THREE.DoubleSide} transparent opacity={0.5} /></mesh>}
      {isValidMove && <mesh position={[0, -0.25, 0]}><cylinderGeometry args={[0.2, 0.2, 0.02, 32]} /><meshStandardMaterial color="green" transparent opacity={0.6} /></mesh>}
    </mesh>
  );
};

const ModelPiece: React.FC<{ piece: Piece; isSelected: boolean; isValidMove: boolean; onClick: (pos: Position) => void }> = ({ piece, isSelected, isValidMove, onClick }) => {
  const url = pieceModelURLs[piece.color][piece.type];
  if (!url) {
    return <PlaceholderPiece piece={piece} onClick={onClick} isSelected={isSelected} isValidMove={isValidMove} />;
  }
  try {
    const { scene } = useGLTF(url);
    return (
      <group position={[piece.position.x - 3.5, 0, piece.position.y - 3.5]} onClick={(e) => { e.stopPropagation(); onClick(piece.position); }}>
        <primitive object={scene} scale={0.5} castShadow />
      </group>
    );
  } catch (e) {
    console.warn('Failed to load model for', piece, e);
    return <PlaceholderPiece piece={piece} onClick={onClick} isSelected={isSelected} isValidMove={isValidMove} />;
  }
};

const Board3D: React.FC<{ boardState: BoardState; selected: Piece | null; validMoves: Position[]; onSquareClick: (pos: Position) => void; }> = ({ boardState, selected, validMoves, onSquareClick }) => {
  const squares: React.ReactNode[] = [];
  for (let x = 0; x < 8; x++) for (let y = 0; y < 8; y++) {
    const color = (x + y) % 2 === 0 ? '#f0d9b5' : '#b58863';
    squares.push(
      <mesh key={`sq-${x}-${y}`} position={[x - 3.5, 0, y - 3.5]} onClick={() => onSquareClick({ x, y })} receiveShadow>
        <boxGeometry args={[1, 0.1, 1]} />
        <meshStandardMaterial color={color} />
      </mesh>
    );
  }
  return (
    <>
      {squares}
      {boardState.map(piece => (
        <Suspense fallback={<PlaceholderPiece piece={piece} onClick={onSquareClick} isSelected={selected?.id === piece.id} isValidMove={validMoves.some(m => m.x === piece.position.x && m.y === piece.position.y)} />} key={piece.id}>
          <ModelPiece piece={piece} onClick={onSquareClick} isSelected={selected?.id === piece.id} isValidMove={validMoves.some(m => m.x === piece.position.x && m.y === piece.position.y)} />
        </Suspense>
      ))}
    </>
  );
};

export default function Chess3D() {
  const initial: BoardState = [];
  const order: Piece['type'][] = ['rook', 'knight', 'bishop', 'queen', 'king', 'bishop', 'knight', 'rook'];
  order.forEach((type, x) => initial.push({ id: `w${type}${x}`, type, color: 'white', position: { x, y: 0 } }));
  for (let x = 0; x < 8; x++) initial.push({ id: `wp${x}`, type: 'pawn', color: 'white', position: { x, y: 1 } });
  for (let x = 0; x < 8; x++) initial.push({ id: `bp${x}`, type: 'pawn', color: 'black', position: { x, y: 6 } });
  order.forEach((type, x) => initial.push({ id: `b${type}${x}`, type, color: 'black', position: { x, y: 7 } }));

  const [board, setBoard] = useState<BoardState>(initial);
  const [history, setHistory] = useState<MoveHistory>([]);
  const [currentPlayer, setCurrentPlayer] = useState<Color>('white');
  const [selected, setSelected] = useState<Piece | null>(null);
  const [validMoves, setValidMoves] = useState<Position[]>([]);

  const handleSquareClick = useCallback((pos: Position) => {
    const piece = getPieceAtPosition(board, pos);
    if (!selected && piece && piece.color === currentPlayer) {
      setSelected(piece);
      const moves: Position[] = [];
      for (let x = 0; x < 8; x++) for (let y = 0; y < 8; y++) if (isValidMove(piece, { x, y }, board, history)) moves.push({ x, y });
      setValidMoves(moves); return;
    }
    if (selected && validMoves.some(m => m.x === pos.x && m.y === pos.y)) {
      const newBoard = makeMove(selected, pos, board);
      setBoard(newBoard);
      setHistory([...history, { piece: selected, to: pos }]);
      setCurrentPlayer(cp => cp === 'white' ? 'black' : 'white');
      setSelected(null); setValidMoves([]); return;
    }
    setSelected(null); setValidMoves([]);
  }, [board, currentPlayer, history, selected, validMoves]);

  return (
    <Canvas shadows camera={{ position: [0, 8, 8], fov: 50 }} style={{ height: '100vh', background: '#111' }}>
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 10, 5]} intensity={0.8} castShadow />
      <OrbitControls makeDefault />
      <Board3D boardState={board} selected={selected} validMoves={validMoves} onSquareClick={handleSquareClick} />
    </Canvas>
  );
}
