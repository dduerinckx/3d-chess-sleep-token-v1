import React from 'react';
import MoveHistory from './MoveHistory';
import { PieceColor, GameState, Move } from '../models/types';
import { formatMove } from '../utils/notationUtils';

interface GameInfoProps {
  currentPlayer: PieceColor;
  gameState: GameState;
  moveHistory: Move[];
  onResetGame: () => void;
  checkState: { white: boolean; black: boolean };
}

const GameInfo: React.FC<GameInfoProps> = ({
  currentPlayer,
  gameState,
  moveHistory,
  onResetGame,
  checkState,
}) => {
  const getGameStatus = () => {
    if (gameState === 'checkmate') {
      const winner = currentPlayer === 'white' ? 'Black' : 'White';
      return `Checkmate! ${winner} wins!`;
    } else if (gameState === 'stalemate') {
      return 'Stalemate! The game is a draw.';
    } else {
      return `${currentPlayer === 'white' ? 'White' : 'Black'}'s turn`;
    }
  };

  const getStatusColor = () => {
    if (gameState === 'checkmate') {
      return 'text-red-500';
    } else if (gameState === 'stalemate') {
      return 'text-amber-500';
    } else if (checkState[currentPlayer]) {
      return 'text-red-500';
    } else {
      return 'text-amber-900';
    }
  };

  const formattedMoves = moveHistory.map((move, index) => ({
    number: Math.floor(index / 2) + 1,
    color: move.piece.color,
    notation: formatMove(move, moveHistory.slice(0, index), gameState),
  }));

  return (
    <div className="bg-amber-50 rounded-lg shadow-md p-6 w-full">
      <h2 className="text-2xl font-bold text-amber-900 mb-4">Game Info</h2>
      
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="font-medium text-amber-900">Status:</span>
          <span className={`font-bold ${getStatusColor()}`}>
            {getGameStatus()}
            {gameState === 'playing' && checkState[currentPlayer] && ' (Check)'}
          </span>
        </div>
        
        <div className="flex items-center mb-4">
          <div className={`w-4 h-4 rounded-full mr-2 ${currentPlayer === 'white' ? 'bg-white border border-black' : 'bg-black'}`}></div>
          <span className="font-bold text-amber-900">{currentPlayer === 'white' ? 'White' : 'Black'} to move</span>
        </div>
        
        <button
          onClick={onResetGame}
          className="w-full py-2 px-4 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded transition-colors duration-200"
        >
          New Game
        </button>
      </div>
      
      <MoveHistory moves={formattedMoves} />
    </div>
  );
};

export default GameInfo;